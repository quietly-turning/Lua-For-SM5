local tween_time = 1.1
local players = {}
local index = 0
local start_y

local tweens = {
	{
		"linear",
		"Execute following commands steadily, at a constant rate."
	},{
		"accelerate",
		"Starts slow, and progressively speeds up."
	},{
		"decelerate",
		"Starts fast, and progressively slows down."
	},{
		"spring",
		"Shoot past the end state, and spring back."
	},
	
	-- these are defined in the _fallback theme in ./Scripts/02 Actor.lua
	{
		"smooth",
		"Slow to start, fast in the middle, slow to finish"
	},{
		"bouncebegin",
		"Briefly inverts the tween to start."
	},{
		"bounceend",
		"Completes the tween, goes a bit beyond, then inverts to return to the desired endpoint."
	},{
		"drop",
		"Slows as it approaches its end state, then briefly accelerates the final few frames."
	},{
		"sleep",
		"Wait for a specified duration, then execute all following commands at once."
	}
}

local af = Def.ActorFrame{
	OnCommand=function(self)
		-- Here in the OnCommand of the primary ActorFrame
		-- get any available Player objects and store them in the
		-- "players" table which has scope over this entire file.

		for player in ivalues(GAMESTATE:GetHumanPlayers()) do
			-- get the Player object for this particular player
			local player = SCREENMAN:GetTopScreen():GetChild('Player'..ToEnumShortString(player))

			-- store this Player object in the "players" table for later retrieval
			players[#players+1] = player

			-- Store the starting y() position of either Player
			-- as they should be the same (right?).
			-- This will allow us to reset/undo our y() tweens.
			start_y = player:GetY()
		end
		
		self:queuecommand("DemoTheNextTween")
	end,
	DemoTheNextTweenCommand=function(self)
		if index < #tweens then
			index = index+1

			for player in ivalues(players) do
				-- call the desired tween on the desired Player object
				-- changing the y position along the way.
				player[ tweens[index][1] ](player, tween_time):y( _screen.h + 100)
				
				-- sleep the Player in its new location for a bit
				-- then reset its position so we can demo the next tween
				player:sleep(tween_time/2):y(start_y)
			end

			self:sleep( tween_time*3 ):queuecommand("DemoTheNextTween")
		else
			self:queuecommand("Hide")
		end
	end,

	Def.Actor{
		InitCommand=function(self)
			-- sleep() an arbitrary actor for 100 seconds as a
			-- means of preserving the FGAnimation (this file).
			-- If SOMETHING isn't actively tweening in a FGCHANGE
			-- then the engine considers the animation
			-- to be complete and clears it from memory.
 			self:sleep(100)
		end
	},


	-- the name of the tween being demonstrated
	Def.BitmapText{
		Name="TweenName",
		Font="Common normal",
		OnCommand=function(self)
			self:Center():zoom(1.5)
		end,
		DemoTheNextTweenCommand=function(self)
			self:settext( tweens[index][1] )
		end,
		HideCommand=function(self) self:visible(false) end
	},
	
	-- the description of the tween being demonstrated
	Def.BitmapText{
		Name="TweenDescription",
		Font="Common normal",
		OnCommand=function(self)
			self:Center():y(_screen.cy+50)
		end,
		DemoTheNextTweenCommand=function(self)
			self:settext( tweens[index][2] )
		end,
		HideCommand=function(self) self:visible(false) end
	}
}

return af